// Ejercicio 1.2 - Análisis de referencias

class Vehiculo {
    String matricula;
    double velocidad;

    Vehiculo(String matricula, double velocidad) {
        this.matricula = matricula;
        this.velocidad = velocidad;
    }
}

public class Ejercicio1_2 {

    static int modificarPrimitivo(int n) {
        n = n + 100;
        return n;
    }

    static void mutarObjeto(Vehiculo v) {
        v.velocidad = 999;
    }

    static void reasignarObjeto(Vehiculo v) {
        v = new Vehiculo("NUEVO-000", 0);
    }

    public static void main(String[] args) {
        // 1. Primitivos: se copia el valor
        int a = 40;
        int b = a;
        b += 20;
        System.out.println("a = " + a + " | b = " + b);

        // 2. Objetos: se copia la referencia
        Vehiculo auto1 = new Vehiculo("XYZ-123", 40);
        Vehiculo auto2 = auto1;
        auto2.velocidad = 60;
        System.out.println("auto1.velocidad = " + auto1.velocidad);
        System.out.println("auto2.velocidad = " + auto2.velocidad);
        System.out.println("auto1 == auto2: " + (auto1 == auto2));

        // 3. Reasignar la variable no modifica el objeto original
        Vehiculo auto3 = auto1;
        auto3 = new Vehiculo("ABC-999", 10);
        System.out.println("auto1.matricula = " + auto1.matricula);
        System.out.println("auto3.matricula = " + auto3.matricula);
        System.out.println("auto1 == auto3: " + (auto1 == auto3));

        // 4. Paso a métodos (en Java siempre se pasa una copia del valor;
        //    en los objetos esa copia es la referencia)
        int numero = 5;
        modificarPrimitivo(numero);
        System.out.println("numero después del método: " + numero);

        mutarObjeto(auto1);
        System.out.println("auto1.velocidad tras mutar: " + auto1.velocidad);

        reasignarObjeto(auto1);
        System.out.println("auto1.matricula tras reasignar en el método: "
                + auto1.matricula);
    }
}
