// Ejercicio 1.1 - Modelado de coordenadas

class Punto3D {
    private double x;
    private double y;
    private double z;

    public Punto3D(double x, double y, double z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    // Distancia euclidiana hacia otro punto
    public double calcularDistancia(Punto3D otro) {
        double dx = this.x - otro.x;
        double dy = this.y - otro.y;
        double dz = this.z - otro.z;
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    // Sobrecarga: distancia al origen (en Java sí existe la sobrecarga)
    public double calcularDistancia() {
        return calcularDistancia(new Punto3D(0, 0, 0));
    }

    @Override
    public String toString() {
        return "Punto3D(" + x + ", " + y + ", " + z + ")";
    }
}

public class Ejercicio1_1 {
    public static void main(String[] args) {
        Punto3D p1 = new Punto3D(1, 2, 3);
        Punto3D p2 = new Punto3D(4, 6, 3);

        System.out.println(p1);
        System.out.println(p2);
        System.out.println("Distancia p1 -> p2: " + p1.calcularDistancia(p2));
        System.out.printf("Distancia p1 -> origen: %.4f%n", p1.calcularDistancia());
        System.out.println("p1 es instancia de Punto3D: " + (p1 instanceof Punto3D));
        System.out.println("p1 == p2: " + (p1 == p2));
    }
}
