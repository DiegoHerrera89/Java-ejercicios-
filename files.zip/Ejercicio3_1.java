// Ejercicio 3.1 - Jerarquía de dispositivos

class DispositivoIoT {
    protected String id;
    protected String ip;
    protected boolean conectado;

    public DispositivoIoT(String id, String ip, boolean conectado) {
        this.id = id;
        this.ip = ip;
        this.conectado = conectado;
    }

    public String describir() {
        return "[" + id + "] " + ip + " - " + (conectado ? "conectado" : "desconectado");
    }
}

class CamaraSeguridad extends DispositivoIoT {
    private String resolucion;

    public CamaraSeguridad(String id, String ip, boolean conectado, String resolucion) {
        super(id, ip, conectado);   // primera instrucción del constructor
        this.resolucion = resolucion;
    }

    @Override
    public String describir() {
        return super.describir() + " | Cámara " + resolucion;
    }
}

class TermostatoInteligente extends DispositivoIoT {
    private double temperaturaObjetivo;

    public TermostatoInteligente(String id, String ip, boolean conectado,
                                 double temperaturaObjetivo) {
        super(id, ip, conectado);
        this.temperaturaObjetivo = temperaturaObjetivo;
    }

    @Override
    public String describir() {
        return super.describir() + " | Termostato a " + temperaturaObjetivo + " °C";
    }
}

public class Ejercicio3_1 {
    public static void main(String[] args) {
        DispositivoIoT dispositivo = new DispositivoIoT("D-001", "192.168.1.10", true);
        CamaraSeguridad camara = new CamaraSeguridad("C-101", "192.168.1.21", true, "1080p");
        TermostatoInteligente termostato =
                new TermostatoInteligente("T-201", "192.168.1.35", true, 22);

        System.out.println(dispositivo.describir());
        System.out.println(camara.describir());
        System.out.println(termostato.describir());

        System.out.println("camara es DispositivoIoT: " + (camara instanceof DispositivoIoT));
    }
}
