// Ejercicio 2.1 - Validación de invariantes

class SensorPresion {
    private double valorPSI = 0;

    public double getValorPSI() {
        return valorPSI;
    }

    public void setValorPSI(double valor) {
        if (Double.isNaN(valor)) {
            throw new IllegalArgumentException("El valor debe ser un número");
        }
        if (valor < 0) {
            throw new IllegalArgumentException("La presión no puede ser negativa");
        }
        if (valor > 200) {
            throw new IllegalArgumentException("La presión no puede superar 200 PSI");
        }
        this.valorPSI = valor;
    }
}

public class Ejercicio2_1 {
    public static void main(String[] args) {
        SensorPresion sensor = new SensorPresion();

        // Los valores llegan como texto para poder probar también "texto"
        String[] pruebas = {"50", "-5", "250", "texto", "200", "0"};

        for (String entrada : pruebas) {
            try {
                double valor = Double.parseDouble(entrada); // falla con "texto"
                sensor.setValorPSI(valor);
                System.out.println("Asignar " + entrada + " -> aceptado. valorPSI = "
                        + sensor.getValorPSI());
            } catch (NumberFormatException e) {
                System.out.println("Asignar " + entrada + " -> NumberFormatException: "
                        + "no es un número. valorPSI sigue en " + sensor.getValorPSI());
            } catch (IllegalArgumentException e) {
                System.out.println("Asignar " + entrada + " -> IllegalArgumentException: "
                        + e.getMessage() + ". valorPSI sigue en " + sensor.getValorPSI());
            }
        }

        // Acceso directo desde fuera: error de compilación (campo privado)
        // sensor.valorPSI = 999;
    }
}
