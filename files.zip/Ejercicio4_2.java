// Ejercicio 4.2 - Desacoplamiento arquitectónico

import java.util.ArrayList;
import java.util.List;

// El contrato es explícito: el compilador lo verifica
interface Suscriptor {
    void actualizarEstado(String tipo, double valor);
}

class DespachadorEventos {
    private List<Suscriptor> suscriptores = new ArrayList<>();

    public int suscribir(Suscriptor s) {
        if (s == null) {
            throw new IllegalArgumentException("El suscriptor no puede ser nulo");
        }
        suscriptores.add(s);
        return suscriptores.size();
    }

    public void notificar(String tipo, double valor) {
        for (Suscriptor s : suscriptores) {
            s.actualizarEstado(tipo, valor);
        }
    }
}

// Tres clases sin relación entre sí; solo comparten la interfaz
class PantallaPanel implements Suscriptor {
    @Override
    public void actualizarEstado(String tipo, double valor) {
        System.out.println("[Pantalla] Mostrando: " + tipo + " (" + valor + ")");
    }
}

class RegistroLog implements Suscriptor {
    private int lineas = 0;

    @Override
    public void actualizarEstado(String tipo, double valor) {
        lineas++;
        System.out.println("[Log] Registro #" + lineas + ": " + tipo + "=" + valor);
    }
}

class Ventilador implements Suscriptor {
    @Override
    public void actualizarEstado(String tipo, double valor) {
        boolean encendido = tipo.equals("temperatura") && valor > 30;
        System.out.println("[Ventilador] " + (encendido ? "ENCENDIDO" : "apagado"));
    }
}

class Sirena {
    // No implementa Suscriptor
    void sonar() { }
}

public class Ejercicio4_2 {
    public static void main(String[] args) {
        DespachadorEventos despachador = new DespachadorEventos();
        despachador.suscribir(new PantallaPanel());
        despachador.suscribir(new RegistroLog());
        despachador.suscribir(new Ventilador());

        // despachador.suscribir(new Sirena());
        // ^ no compila: Sirena no cumple el contrato Suscriptor

        despachador.notificar("temperatura", 35);
        System.out.println("---");
        despachador.notificar("temperatura", 22);
    }
}
