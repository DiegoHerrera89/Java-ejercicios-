// Ejercicio 4.1 - Simulador de renderizado

import java.util.ArrayList;
import java.util.List;

interface Figura {
    String dibujar();
}

class Circulo implements Figura {
    private double radio;

    Circulo(double radio) {
        this.radio = radio;
    }

    @Override
    public String dibujar() {
        double area = Math.PI * radio * radio;
        return String.format("Círculo r=%.0f -> área = π·r² = %.2f", radio, area);
    }
}

class Rectangulo implements Figura {
    private double base;
    private double altura;

    Rectangulo(double base, double altura) {
        this.base = base;
        this.altura = altura;
    }

    @Override
    public String dibujar() {
        return String.format("Rectángulo %.0fx%.0f -> área = %.2f", base, altura, base * altura);
    }
}

class Triangulo implements Figura {
    private double base;
    private double altura;

    Triangulo(double base, double altura) {
        this.base = base;
        this.altura = altura;
    }

    @Override
    public String dibujar() {
        return String.format("Triángulo %.0fx%.0f -> área = %.2f", base, altura,
                base * altura / 2);
    }
}

public class Ejercicio4_1 {
    public static void main(String[] args) {
        List<Figura> figuras = new ArrayList<>();
        figuras.add(new Circulo(3));
        figuras.add(new Rectangulo(4, 5));
        figuras.add(new Triangulo(6, 2));

        // Sin instanceof: el enlace dinámico elige la versión de cada objeto
        for (Figura figura : figuras) {
            System.out.println(figura.dibujar());
        }
    }
}
