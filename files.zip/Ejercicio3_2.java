// Ejercicio 3.2 - Sobreescritura controlada

class DispositivoIoT {
    protected String id;
    protected String ip;
    protected boolean conectado;

    public DispositivoIoT(String id, String ip, boolean conectado) {
        this.id = id;
        this.ip = ip;
        this.conectado = conectado;
    }

    // Consumo base en vatios: depende del estado de la conexión
    public double consumoEnergetico() {
        return conectado ? 5 : 1;
    }
}

class CamaraSeguridad extends DispositivoIoT {
    public CamaraSeguridad(String id, String ip, boolean conectado) {
        super(id, ip, conectado);
    }

    // Factor de ponderación 2.5: sensor de imagen + transmisión de video
    @Override
    public double consumoEnergetico() {
        return super.consumoEnergetico() * 2.5;
    }
}

class TermostatoInteligente extends DispositivoIoT {
    public TermostatoInteligente(String id, String ip, boolean conectado) {
        super(id, ip, conectado);
    }

    // Factor de ponderación 1.4: electrónica de control y pantalla
    @Override
    public double consumoEnergetico() {
        return super.consumoEnergetico() * 1.4;
    }
}

public class Ejercicio3_2 {
    public static void main(String[] args) {
        DispositivoIoT[] dispositivos = {
            new DispositivoIoT("D-001", "192.168.1.10", true),
            new CamaraSeguridad("C-101", "192.168.1.21", true),
            new TermostatoInteligente("T-201", "192.168.1.35", true),
            new CamaraSeguridad("C-102", "192.168.1.22", false)
        };

        for (DispositivoIoT d : dispositivos) {
            System.out.printf("%s (%s) -> consumo: %.1f W%n",
                    d.id, d.getClass().getSimpleName(), d.consumoEnergetico());
        }
    }
}
