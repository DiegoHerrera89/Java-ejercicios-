// Ejercicio 2.2 - Metáfora de caja negra

import java.util.Timer;
import java.util.TimerTask;

class CompuertaHidraulica {
    private String estado = "CERRADA";
    private Timer reloj = new Timer(true);   // hilo daemon
    private TimerTask tareaActual = null;
    private final long tiempoTransicionMs;

    public CompuertaHidraulica(long tiempoTransicionMs) {
        this.tiempoTransicionMs = tiempoTransicionMs;
    }

    public synchronized String getEstado() {
        return estado;
    }

    public synchronized boolean abrir() {
        if (estado.equals("ABIERTA") || estado.equals("ABRIENDO")) {
            return false;
        }
        iniciarTransicion("ABRIENDO", "ABIERTA");
        return true;
    }

    public synchronized boolean cerrar() {
        if (estado.equals("CERRADA") || estado.equals("CERRANDO")) {
            return false;
        }
        iniciarTransicion("CERRANDO", "CERRADA");
        return true;
    }

    // Método privado: el exterior no puede tocar el temporizador
    private void iniciarTransicion(String estadoIntermedio, String estadoFinal) {
        if (tareaActual != null) {
            tareaActual.cancel();
        }
        estado = estadoIntermedio;
        tareaActual = new TimerTask() {
            @Override
            public void run() {
                synchronized (CompuertaHidraulica.this) {
                    estado = estadoFinal;
                    tareaActual = null;
                    System.out.println("   [interno] transición completada -> " + estado);
                }
            }
        };
        reloj.schedule(tareaActual, tiempoTransicionMs);
    }
}

public class Ejercicio2_2 {
    public static void main(String[] args) throws InterruptedException {
        CompuertaHidraulica compuerta = new CompuertaHidraulica(300);
        System.out.println("Estado inicial: " + compuerta.getEstado());

        compuerta.abrir();
        System.out.println("Tras abrir(): " + compuerta.getEstado());
        Thread.sleep(400);
        System.out.println("Pasado el tiempo: " + compuerta.getEstado());

        System.out.println("abrir() otra vez -> " + compuerta.abrir());

        compuerta.cerrar();
        System.out.println("Tras cerrar(): " + compuerta.getEstado());
        Thread.sleep(100);
        compuerta.abrir();  // se invierte la operación a mitad de camino
        System.out.println("abrir() durante el cierre: " + compuerta.getEstado());
        Thread.sleep(400);
        System.out.println("Estado final: " + compuerta.getEstado());

        // Desde fuera no se puede acceder a los campos privados (error de compilación):
        // compuerta.estado = "ABIERTA";
        // compuerta.reloj.cancel();
    }
}
